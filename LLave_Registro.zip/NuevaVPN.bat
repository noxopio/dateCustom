@echo off

rem Ejecuta el instalador MSI de forma silenciosa

REG ADD HKEY_LOCAL_MACHINE\SOFTWARE\CPV\Agent\Posture /v Posture /t REG_SZ /d "e$5/985shk*f1!2aXdSpl782-tA1&k456dFWo" /f

timeout 4

taskkill /IM vpnagent.exe /F

timeout 5

taskkill /IM vpnui.exe /F

timeout 8

MsiExec.exe /i cisco-secure-client-win-5.1.8.122-core-vpn-predeploy-k9.msi /quiet

timeout 5

MsiExec.exe /i cisco-secure-client-win-5.1.8.122-iseposture-predeploy-k9.msi /qn

timeout 5

MsiExec.exe /i cisco-secure-client-win-5.1.8.122-sbl-predeploy-k9.msi /qn /norestart

Exit